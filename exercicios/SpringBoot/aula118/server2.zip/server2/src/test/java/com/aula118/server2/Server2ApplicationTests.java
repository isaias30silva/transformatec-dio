package com.aula118.server2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Server2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
