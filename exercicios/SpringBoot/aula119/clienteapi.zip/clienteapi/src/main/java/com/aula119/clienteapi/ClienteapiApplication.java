package com.aula119.clienteapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteapiApplication.class, args);
	}

}
