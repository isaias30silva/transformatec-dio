package com.aula119.clienteapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
